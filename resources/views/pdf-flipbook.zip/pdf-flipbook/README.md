# PDF FLIPBOOK
Pdf flipbook converter with turnjs and pdfjs libraries.

## Demo
![alt tag](http://eray.info/demo/pdf-flipbook/ompressed.tracemonkey-pldi-09.pdf20161028171848.gif)

[Demo](http://eray.info/demo/pdf-flipbook)

## Usage

#### Define PDF Src

to define the src, open pdfjs/viewer.js and change to line 30.
```javascript
var DEFAULT_URL =  "compressed.tracemonkey-pldi-09.pdf";
```

 
